# Views production checklist
This is a functional product foundation/demo. Before public launch:
- Run supabase/schema.sql in Supabase.
- Create the media Storage bucket and configure RLS.
- Add profile onboarding and username/phone/age validation.
- Add RLS policies to every database table and Storage object.
- Add realtime presence, typing, notifications and chat.
- Implement audited device-side E2EE; ordinary TLS/database encryption is not E2EE.
- Add CDN/transcoding for images, thumbnails and 1-minute videos.
- Add licensed/current APIs for sports, markets, travel and news.
- Add rights/embedding controls for documentaries and music.
- Add compliant donations/payments and fraud controls.
- Add location permissions and coarse-location privacy controls.
- Add moderation, rate limiting, abuse prevention, monitoring and load tests.
- Never expose a Supabase secret/service-role key in browser code.
