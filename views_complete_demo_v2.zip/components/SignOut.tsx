'use client'
import{createClient}from'@/lib/supabase/client';import{useRouter}from'next/navigation'
export default function SignOut(){const r=useRouter();return <button className="btn" onClick={async()=>{await createClient().auth.signOut();r.push('/login');r.refresh()}}>Log out</button>}
