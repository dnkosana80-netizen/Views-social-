'use client'
import{useState}from'react';import{createClient}from'@/lib/supabase/client'
export default function LikeButton({postId,initialLiked,initialCount}:{postId:string,initialLiked:boolean,initialCount:number}){const[l,setL]=useState(initialLiked),[n,setN]=useState(initialCount),[busy,setBusy]=useState(false);async function go(){if(busy)return;const a=l,b=n;setL(!a);setN(b+(a?-1:1));setBusy(true);const{error}=await createClient().rpc('toggle_post_like',{p_post_id:postId});if(error){setL(a);setN(b)}setBusy(false)}return <button className="btn" onClick={go}>{l?'❤️':'♡'} {n}</button>}
