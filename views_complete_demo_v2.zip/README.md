# Views Social V1.1
Built against the Supabase project supplied in the conversation.
Run:
npm install
npm run dev

Then open http://localhost:3000.

Setup in Supabase:
1. Run supabase/schema.sql.
2. Create a Storage bucket named `media` and configure RLS/storage policies.
3. Configure Auth email settings.
4. Add profile creation/onboarding and production RLS policies before public launch.

The supplied publishable key is used as requested. Never put a secret/service-role key in the browser.
