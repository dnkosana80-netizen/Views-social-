import './globals.css'
export const metadata={title:'Views',description:'See more. Share more. Connect better.'}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
