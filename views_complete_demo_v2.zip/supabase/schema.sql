-- VIEWS SOCIAL V1.1
create extension if not exists pgcrypto;
create table if not exists profiles(id uuid primary key references auth.users(id) on delete cascade,username varchar(30) unique not null,display_name varchar(50) not null,email varchar(255) unique not null,phone varchar(30),age smallint check(age between 13 and 120),avatar_url text,bio varchar(160),created_at timestamptz default now());
create table if not exists follows(follower_id uuid references profiles(id) on delete cascade,following_id uuid references profiles(id) on delete cascade,created_at timestamptz default now(),primary key(follower_id,following_id),check(follower_id<>following_id));
create table if not exists posts(id uuid primary key default gen_random_uuid(),user_id uuid references profiles(id) on delete cascade not null,media_url text not null,media_type varchar(10) not null check(media_type in('image','video')),caption text,music_id text,place_name text,likes_count bigint default 0,comments_count bigint default 0,shares_count bigint default 0,saves_count bigint default 0,created_at timestamptz default now());
create table if not exists likes(user_id uuid references profiles(id) on delete cascade,post_id uuid references posts(id) on delete cascade,created_at timestamptz default now(),primary key(user_id,post_id));
create table if not exists comments(id uuid primary key default gen_random_uuid(),post_id uuid references posts(id) on delete cascade,user_id uuid references profiles(id) on delete cascade,body text not null,created_at timestamptz default now());
create table if not exists saves(user_id uuid references profiles(id) on delete cascade,post_id uuid references posts(id) on delete cascade,primary key(user_id,post_id));
create table if not exists reposts(user_id uuid references profiles(id) on delete cascade,post_id uuid references posts(id) on delete cascade,primary key(user_id,post_id));
create table if not exists statuses(id uuid primary key default gen_random_uuid(),user_id uuid references profiles(id) on delete cascade,media_url text not null,media_type varchar(10) not null,caption text,created_at timestamptz default now(),expires_at timestamptz default(now()+interval '24 hours'));
create index if not exists idx_posts_created on posts(created_at desc,id desc);
create index if not exists idx_posts_user on posts(user_id,created_at desc,id desc);
create index if not exists idx_likes_post on likes(post_id);

create or replace function toggle_post_like(p_post_id uuid) returns boolean language plpgsql security definer as $$
declare r boolean;
begin
 if exists(select 1 from likes where user_id=auth.uid() and post_id=p_post_id) then delete from likes where user_id=auth.uid() and post_id=p_post_id; update posts set likes_count=greatest(0,likes_count-1) where id=p_post_id;r:=false;
 else insert into likes(user_id,post_id) values(auth.uid(),p_post_id);update posts set likes_count=likes_count+1 where id=p_post_id;r:=true;end if;return r;
end$$;

create or replace function get_chronological_feed(p_limit int default 20) returns table(id uuid,username varchar,avatar_url text,media_url text,caption text,likes_count bigint,is_liked boolean,created_at timestamptz) language sql security definer as $$
select p.id,pr.username,pr.avatar_url,p.media_url,p.caption,p.likes_count,exists(select 1 from likes l where l.post_id=p.id and l.user_id=auth.uid()),p.created_at from posts p join profiles pr on pr.id=p.user_id where p.user_id=auth.uid() or p.user_id in(select following_id from follows where follower_id=auth.uid()) order by p.created_at desc,p.id desc limit least(greatest(p_limit,1),50)$$;

-- IMPORTANT: enable RLS and add explicit policies for every production table.
-- Create Storage bucket "media" and policies allowing authenticated users to upload only into their own user-id folder.
